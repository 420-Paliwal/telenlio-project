package com.telenlio.crudproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}

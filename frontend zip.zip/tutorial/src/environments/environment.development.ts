export const environment = {
    api_url:'https://freeapi.miniprojectideas.com/api/ClientStrive/',
};
